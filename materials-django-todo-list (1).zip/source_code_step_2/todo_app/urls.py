# todo_list/todo_app/urls.py

urlpatterns = []
